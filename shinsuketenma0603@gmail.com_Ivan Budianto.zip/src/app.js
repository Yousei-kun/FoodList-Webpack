import "regenerator-runtime";
import "bootstrap/dist/css/bootstrap.min.css";
import "./style/style.css";
import "./style/style.scss";

import main from "./script/view/main.js";

document.addEventListener("DOMContentLoaded", main);